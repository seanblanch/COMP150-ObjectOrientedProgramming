/**
 * GuessMyLetters
 * <p>
 * Implements letter guessing game
 *
 * @author Sean Blanchard
 * @version 11/26/18
 */

import com.sun.deploy.util.ArrayUtil;

import java.util.*;

public class GuessMyLetters
{
    private ArrayList<Integer> scores; // ArrayList of wrong guess counters
    private char[] phrase;             // holds array representation of input, must be created by setGame
    private char[] maskedPhrase;       // hold masked representation of input, must be created by setGame

    /** constructor
     *    creates this.scores object
     */
    public GuessMyLetters()
    {

        // TODO
        this.scores = new ArrayList<>();



    }

    /**
     *   setGame will always be called by the client only
     *
     *   sets this.phrase array to the passed input
     *   creates this.maskedPhrase array and
     *   fills this.maskedPhrase with * or space characters
     */
    public void setGame(char... input)
    {

        // TODO
        this.phrase = new char[input.length];
        for (int i = 0; i < this.phrase.length; i++){
            this.phrase[i] = Character.toLowerCase(input[i]);
        }
        this.maskedPhrase = new char[this.phrase.length];

        for (int index = 0; index < this.maskedPhrase.length; index++) {
            if (this.phrase[index] == ' ') {
                maskedPhrase[index] = ' ';
            } else {
                maskedPhrase[index] = '*';
            }
        }







    }

    /**
     *
     * displays each character from this.maskedPhrase array in one row
     */
    public void displayMaskedPhrase()
    {

        // TODO
        for (int i=0; i < this.maskedPhrase.length; i++){
            System.out.print(maskedPhrase[i] + " ");
    }



    }

    /**
     *
     * keeps prompting the user for guesses until all letters are guessed
     *    1. calls checkTheLetters method to determine if the guess is part of the phrase
     *       1a.  updates the wrongCount in case the guess is not in the phrase
     *    2. calls displayMaskedPhrase
     *    3. calls guessedAllLetters
     *       3a.  adds the wrongGuessCount to this.score when all letters are guessed
     *
     * @return the number of wrong guesses
     */
    public int guessTheLetters()
    {
        int wrongGuessCount = 0;

        // TODO



        do {
            System.out.println();
            displayMaskedPhrase();
            System.out.println();
            System.out.println("--> guess a letter ");
            Scanner scan = new Scanner(System.in);
            char s = scan.next().charAt(0);
            if (!checkTheLetters(s)){
                wrongGuessCount+=1;
                System.out.println("--> " + s + " was not found");
            } else {
                System.out.print("--> " + s + " was found");
            }
            guessedAllLetters();
        } while (!guessedAllLetters());



        this.scores.add(wrongGuessCount);
        this.scores.trimToSize();









        return wrongGuessCount;
    }

    /**
     * checks if the letter guess is in the phrase
     *   and if it is, updates this.maskedPhase by changing the * into the guessed letter
     *   looks for ALL occurrences of the letter in the phrase
     *
     *   NOTE: the guess must be converted to upper case with Character.toUpperCase method
     *
     *  @return true if the guess was found at least once
     */
    public boolean checkTheLetters(char guess)
    {
        boolean found = false;

        // TODO
        for (int i=0; i < phrase.length; i++){
            if (this.phrase[i] == guess){
                this.maskedPhrase[i] = Character.toUpperCase(guess);
                found = true;
            }

        }




        return found;
    }

    /**
     * checks if this.maskedPhrase has at least one *
     *
     * @return true if no * found
     */
    public boolean guessedAllLetters()
    {
        boolean done = true;

        // TODO
        for(int i = 0; i < this.maskedPhrase.length; i++){
            if(this.maskedPhrase[i] == '*'){
                done = false;
                break;
            }
        }





        return done;
    }

    /**
     * displays the content of this.scores using for-each loop
     */
    public void displayScores()
    {

        // TODO

        for (int i = 0; i < this.scores.size(); i++ ) {
            System.out.println("The final scores are: ");
                System.out.println("Run #" + i + " " + this.scores.get(i) + " wrong;");
            }




    }

    /**
     * creates string representation of this.phrase, this.maskedPhrase and this.scores
     * utilizes StringBuilder
     */
    public String toString()
    {
        StringBuilder toReturn = new StringBuilder();

        // TODO

        for(int i = 0; i < maskedPhrase.length; i++){
            toReturn.append(this.phrase[i]);
        }

        toReturn.append("; maskedPhrase is: ");
        for(int i = 0; i < maskedPhrase.length; i++){
            toReturn.append(this.maskedPhrase[i]);
        }
        toReturn.append("; scores are:");
        if (this.scores.isEmpty()) {
            toReturn.append(" EMPTY");
        } else {
        for(int score : this.scores) {

                toReturn.append(" " + score);
            }
        }







        return toReturn.toString();
    }

}