/**
 * GuessMyLettersClient
 *
 * @author Sean Blanchard
 * @version 11/26/18
 */

import java.io.*;
import java.util.Scanner;

public class GuessMyLettersClient
{
    public static void main(String[] args) throws IOException
    {
        System.out.println("*** SETTING UP THE \"GUESS MY LETTERS\" GAME ***\n");
        GuessMyLetters game = new GuessMyLetters();

        String phraseToGuess;
        int score;
        String fileName = "input.txt";
        Scanner file = new Scanner(new File(fileName));
        while (file.hasNext()) // test for end of file
        {
            phraseToGuess = file.nextLine();  // read a line
            phraseToGuess = phraseToGuess.toUpperCase(); // convert to upper case
            game.setGame(phraseToGuess.toCharArray()); // pass array representation of the String
            System.out.println("-----> for debugging, Phrase is: " + game.toString());
            score = game.guessTheLetters();
            System.out.println("\n" + "--> You've got " + score + " wrong!\n");
        }
        game.displayScores();
        // release resources associated with fileName
        file.close();
    }
}
