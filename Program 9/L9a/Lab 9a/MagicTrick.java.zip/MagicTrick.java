package Lab; /**
 * Service class with supporting methods for Magic Trick
 *
 * @author Sean Blanchard
 * @version 11/11/18
 * Lab 9a
 */

import java.util.*;

public class MagicTrick
{
    private int[][] grid;
    private int flippedRow;
    private int flippedCol;
    public static final int GRID_SIZE = 6;

    /**
     * default constructor,
     * sets elements in the grid to randomly generated either 0 or 1
     * calls setParity method
     */
    public MagicTrick()
    {

        // TODO
        // see Lab9a Notes
        this.grid = new int [GRID_SIZE][GRID_SIZE]; //Create new grid 6by6 using final GRID_SIZE

        Random number =  new Random();
        for(int i = 0; i<this.grid.length; i++){
            for(int z=0; z<this.grid[i].length; z++){
                this.grid[i][z] = number.nextInt(2-0); //Create numbers between 0-1
            }
        }
        setParity();


    }

    /**
     * sets elements in the last row and the last column
     * to either 1 or 0, so the sum of the elements in the appropriate row and column is even
     */
    public void setParity()
    {

        // TODO
        // See Lab9a Notes
        int rsum;
        int csum;
        for (int row = 0; row<this.grid.length; row++){
            rsum = 0;
            for(int col = 0; col < this.grid[row].length-1; col++){
                rsum += this.grid[row][col];
                }
                if(rsum%2==1){
                    this.grid[row][GRID_SIZE - 1] = 1;
                } else {
                    this.grid[row][GRID_SIZE - 1] = 0;
                }
            }
            for(int col = 0; col < GRID_SIZE - 2; col++){
                csum = 0;
                for(int row = 0; row < GRID_SIZE - 1; row++){
                    csum += this.grid[row][col];
                }
                if(csum % 2 == 1) {
                this.grid[GRID_SIZE -1][col] = 1;
                } else{
                    this.grid[GRID_SIZE - 1][col] = 0;
                }
            }

    }



    /**
     * flips the value of the randomly
     * selected element, saves the row and col in this.flippedRow and this.flippedCol
     */
    public void flipOneElement()
    {
        // TODO
        // See Lab9a Notes
        Random number = new Random();
        flippedRow = number.nextInt(GRID_SIZE-0);
        flippedCol = number.nextInt(GRID_SIZE-0);
        int newFlipRow=this.grid.length-1-flippedRow;
        int value1 = this.grid[flippedRow][flippedCol];
        int value2 = this.grid[newFlipRow][flippedCol];
        this.grid[flippedRow][flippedCol]=value2;
        this.grid[newFlipRow][flippedCol] = value1;

    }

    /**
     * accessor method
     *
     * @return the value of the row of the flipped element: this.flippedRow
     */
    public int getFlippedRow()
    {
        // TODO

        return this.flippedRow; // THIS IS A STUB
    }

    /**
     * accessor method
     *
     * @return the value of the column of the flipped element: this.flippedCol
     */
    public int getFlippedColumn()
    {
        //TODO

        return this.flippedCol; // THIS IS A STUB
    }

    /**
     * toString method returns printable version
     * of the content of this.grid
     */
    public String toString()
    {
        String returnValue = "";
        for (int r = 0; r < GRID_SIZE; r++)
        {
            for (int c = 0; c < GRID_SIZE; c++)
            {
                returnValue += this.grid[r][c] + " ";
            }
            returnValue += "\n";
        }
        return returnValue += "\n";
    }


    /**
     * checks the user's guess
     *
     * @param r - the row selected by the user
     * @param c - the column selected by the user
     * @return - true if the guessed row and column are the same
     * as the row and column of the flipped element
     */
    public boolean checkGuess(int r, int c)
    {
        // TODO
        if((flippedRow==r) && (flippedCol==c)) {

            return true;
        } else {
            return false;
        }
    }

    // THIS IS A STUB
    }
